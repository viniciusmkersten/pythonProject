from exercicio1_POO import *

objeto = Funcionario('Vinicius', '3000')
objeto.mostrarNome()
objeto.mostrarSalario()

