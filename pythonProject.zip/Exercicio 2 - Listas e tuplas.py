import collections


lista = str(input('digite a(s) palavras a serem achadas: '))

texto = str(input('Digite um texto: '))





stringEmLista = texto.split()
#print(stringEmLista)
qtdeElementos = len(stringEmLista)
#print(qtdeElementos)



for i in range(len(stringEmLista)):
    #elementoEncontrado = stringEmLista.find('laranja')
    if stringEmLista[i] in lista[0]:
        print('O elemento esta na lista. ')
    else:
        print('O elemento n esta na lista. ')