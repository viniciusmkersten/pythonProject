setPessoa = set()

for recebe in range(1):
    nome = setPessoa.add(input('Digite o seu nome: '))
    idade = setPessoa.add(input('Digite a sua idade: '))
    sexo = setPessoa.add(input('Digite o sexo: '))

    print(setPessoa)
