for numero in range (0,12,2):
    print(numero)