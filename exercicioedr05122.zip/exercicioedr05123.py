contador = 1
while contador <= 50:
    print(contador)
    contador += 1